﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HolePunching
{
    public enum MessageType
    {
        Register,
        RequestClient,
        ConnectClient,
        Unregister
    }
}
